var {jigsaw,jigsawserver}=require("jigsaw.js")("39.108.72.242:793");

let A=new jigsaw("A");
let a=A.portTo("B:b",console.log);
A.onReady(()=>{
	
	for(let i=0;i<1000;i++)
		a.send({hello:i+""});


});