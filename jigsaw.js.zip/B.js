var {jigsaw,jigsawserver}=require("jigsaw.js")("39.108.72.242:793");

let B=new jigsaw("B");

B.portTo("b");
B.recv("b",(data)=>{
	return {hellotoo:"我收到你的消息了,是:  "+data.hello};
})