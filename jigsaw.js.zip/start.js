var {jigsaw,jigsawserver}=require("jigsaw.js")(require("./server.txt"));


var {fork}=require("child_process");
new jigsawserver();

fork("./A.js");
fork("./B.js");

