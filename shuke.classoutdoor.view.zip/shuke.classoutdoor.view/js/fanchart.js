window.FanchartManage=(function(){
	function Fanchart(value){
		this.fanchart1=document.getElementById('fanchart1');
		this.fanchart2=document.getElementById('fanchart2');
		this.fanchart3=document.getElementById('fanchart3');
		this.percentageFont=document.getElementById('fanchartBg_number');
		this.angle=value*2.7;
		this.value=value;
		this.rotate();
		this.percentage();
	}
	Fanchart.prototype.rotate=function(){
		//删除并重置@keyframes
		var resetkeyframes=(value1,value2,value3)=>{
			//删除
			for(var i=document.styleSheets[1].cssRules.length-1;i>=0;i--){
				document.styleSheets[1].deleteRule(i);
			}
			//重置
			var rotatekeyframes1=`@-webkit-keyframes rotateDiv1 { 
									0% {transform: rotate(-135deg) skewY(-90deg);} 
									100% {transform: rotate(-135deg) skewY(`+value1+`deg);}
								}` 
			var rotatekeyframes2=`@-webkit-keyframes rotateDiv2 {
									0% {transform: rotate(-45deg) skewY(-90deg);}
									100% {transform: rotate(-45deg) skewY(`+value2+`deg);}
								}`
			var rotatekeyframes3=`@-webkit-keyframes rotateDiv3 {
									0% {transform: rotate(45deg) skewY(-90deg);}
									100% {transform: rotate(45deg) skewY(`+value3+`deg);}
								}`
			document.styleSheets[1].insertRule(rotatekeyframes1,0);
			document.styleSheets[1].insertRule(rotatekeyframes2,1);
			document.styleSheets[1].insertRule(rotatekeyframes3,2);
		}
		if(this.angle>=0 && this.angle<=90){
			this.fanchart1.className='fanchart fanchart1';
			resetkeyframes(this.angle-90,-90,-90);
			setTimeout(()=>{
				this.fanchart1.style.animationTimingFunction='ease';
				this.fanchart1.className=this.fanchart1.className+' fanchart1Rotate';
			},100)
		}
		if(this.angle>90 && this.angle<=180){
			this.fanchart1.className='fanchart fanchart1';
			this.fanchart2.className='fanchart fanchart2';
			resetkeyframes(0,this.angle-180,-90);
			setTimeout(()=>{
				this.fanchart1.className=this.fanchart1.className+' fanchart1Rotate';
				this.fanchart1.style.animationTimingFunction= 'ease-in';
			},100)
			setTimeout(()=>{
				this.fanchart2.className=this.fanchart2.className+' fanchart2Rotate';
				this.fanchart2.style.animationTimingFunction= 'ease-out';
			},500)
		}
		if(this.angle>180 && this.angle<=270){
			this.fanchart1.className='fanchart fanchart1';
			this.fanchart2.className='fanchart fanchart2';
			this.fanchart3.className='fanchart fanchart3';
			resetkeyframes(0,0,this.angle-270);
			setTimeout(()=>{
				this.fanchart1.className=this.fanchart1.className+' fanchart1Rotate';
				this.fanchart1.style.animationTimingFunction= 'ease-in';
			},100)
			setTimeout(()=>{
				this.fanchart2.className=this.fanchart2.className+' fanchart2Rotate';
				this.fanchart2.style.animationTimingFunction= 'linear';
			},500)
			setTimeout(()=>{
				this.fanchart3.className=this.fanchart3.className+' fanchart3Rotate';
				this.fanchart3.style.animationTimingFunction= 'ease-out';
			},900)
		}
	}
	Fanchart.prototype.percentage=function(){
		if(this.value === 100){
			this.percentageFont.style.left=33+'%';
		}
		else {
			this.percentageFont.style.left=36+'%';
		}
		this.percentageFont.innerText=this.value + '%';
	}
	function FanchartManage(){
		
	}
	FanchartManage.prototype.inputValue=function(percentageValue){
		new Fanchart(percentageValue);
	}
	return FanchartManage;
}());
var fanchartManage=new FanchartManage();