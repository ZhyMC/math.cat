var sleep=(t)=>new Promise((y)=>setTimeout(y,t));
class jigsawWebSocket{
constructor(jgname){
this.ws=new WebSocket(window.jgurl);
this.jgname=jgname;
this.ws.onopen=()=>{
	this.ready=true;
	this.send_({action:"listen",portTo:""});
}
this.response=undefined;

this.ws.onmessage=(evt)=>{	
	let obj=JSON.parse(evt.data+"");

	if(obj.response)
	{
		if(!obj.data)
		this.response=null;
		else
		this.response=JSON.parse(obj.data);
	
	}
	else{
		this.listeners[obj.portTo](JSON.parse(obj.data));
		
	}
}
this.listeners={};

this.ready=false;
this.queue=[];
this.eventLoop();

}
async onReady(){
	while(true){
		if(this.ready)
			break;
		await sleep(100);
	}
	
}
async eventLoop(){
while(true){
	let dt=this.queue.shift();
	if(!dt){await sleep(100);continue;}
	this.send_({action:"send",portTo:dt.portTo,data:dt.data});
	
	await (async()=>{
		let timeout=false;
		let timer=setTimeout(()=>{
			timeout=true;
		},5000);
		
		while(true){

		if(timeout){console.log("Jigsaw存在超时请求,已自动跳过");break;}
		
		if(typeof(this.response)!="undefined"){
			clearTimeout(timer);
			dt.callback(this.response);this.response=undefined;break;
			}
			
		await sleep(100);
	
		}
		
	})();
	
	await sleep(100);
}	
	
}
async send_(obj){
	await this.onReady();
	obj.myjgname=this.jgname;
	this.ws.send(JSON.stringify(obj));
}
send(portTo,data){
	return new Promise((callback)=>
	this.queue.push({portTo,data,callback}));
	
}
listen(portTo,callback){
	this.send_({action:"listen",portTo});
	this.listeners[portTo]=callback;
}
}
/*
window.jgurl="ws://127.0.0.1:3335/";
var wsa=new jigsawWebSocket("wsa");
var wsb=new jigsawWebSocket("wsb");

wsa.listen("abc",(data)=>{
	console.log(data);
});

wsb.send("doTest:do",{abc:123}).then(console.log)
*/
/*
ws.send("test",{
	test:123
});
*/
window.jigsaw=jigsawWebSocket;