;(()=>{
	var c=document.getElementById('myCanvas');
	c.width=c.clientWidth;
	c.height=c.clientHeight;
	var ctx=c.getContext('2d');
	ctx.moveTo(4,4);
	ctx.lineTo(c.clientWidth-2,c.clientHeight*0.4);
	ctx.strokeStyle = "rgba(26, 197, 216, 1)";
	ctx.stroke();
	ctx.moveTo(c.clientWidth-2,c.clientHeight*0.4);
	ctx.lineTo(c.clientWidth-2,c.clientHeight);
	ctx.stroke();
	ctx.beginPath();
	ctx.arc(4,4,4,0,2*Math.PI);
	ctx.fillStyle="rgba(26, 197, 216, 1)";
	ctx.fill();
})()