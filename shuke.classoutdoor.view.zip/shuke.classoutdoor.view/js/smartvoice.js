	function Voice(listen){
		this.listen=listen;
		this.scroll=new Scroll('bar','scroll','answerAndquestion_box_bigBox','answerAndquestion_box_content','answerAndquestion_box');
		
		// this.listen((data)=>{
		// 	this.createAnswer();
		// 	this.scroll.createScroll2();
		// });
	}
	Voice.createQues=function(ask){
		var smartVoice_box=document.createElement('div');
		smartVoice_box.id='smartVoice_box';
		smartVoice_box.className='appear';
		document.getElementById('answerAndquestion_box_content').appendChild(smartVoice_box);
		var question_box=document.createElement('div');
		question_box.id='question_box';
		smartVoice_box.appendChild(question_box);
		var question_spot=document.createElement('div');
		question_spot.id='question_spot';
		question_box.appendChild(question_spot);
		var question_box_content=document.createElement('div');
		question_box_content.id='question_box_content';
		question_box_content.innerText=ask;
		question_box.appendChild(question_box_content);
			document.getElementById("answerAndquestion_box_bigBox").scrollTop=999999999;

	}
	Voice.createAnswer=function(ans){
		
		var smartVoice_box=document.createElement('div');
		document.getElementById('answerAndquestion_box_content').appendChild(smartVoice_box);
		var answer_box=document.createElement('div');
		answer_box.id='answer_box';
		smartVoice_box.appendChild(answer_box);
		var answer_spot=document.createElement('div');
		answer_spot.id='answer_spot';
		answer_box.appendChild(answer_spot);
		var answer_box_content=document.createElement('div');
		answer_box_content.id='answer_box_content';
		answer_box_content.innerText=ans;
		answer_box.appendChild(answer_box_content);
		document.getElementById("answerAndquestion_box_bigBox").scrollTop=999999999;

	}
	Voice.listener=function(){
		this.createAnswer();
		this.scroll.createScroll2();
	}

window.Voice=Voice;