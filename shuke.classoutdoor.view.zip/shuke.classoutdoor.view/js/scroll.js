;(function(window,undefined){
	var flag;
	function Scroll(barId,scrollId,parentDiv,content,bigDiv){
		this.bar=document.getElementById(barId);
		this.scroll=document.getElementById(scrollId);
		this.content_big=document.getElementById(parentDiv);
		this.content=document.getElementById(content);
		this.bigDiv=document.getElementById(bigDiv);
	}
	Scroll.prototype.createScroll=function(){
		this.scroll.style.height=this.content.scrollHeight > this.content_big.clientHeight ?this.content_big.clientHeight/this.content.scrollHeight*this.content_big.clientHeight+'px' : 0+'px';
		this.scroll.style.top=0+'px';
		this.content_roll();
	}
	Scroll.prototype.createScroll2=function(){
		this.scroll.style.height=this.content.scrollHeight > this.content_big.clientHeight ?this.content_big.clientHeight/this.content.scrollHeight*this.content_big.clientHeight+'px' : 0+'px';
		this.scroll.style.top=this.bar.clientHeight-this.scroll.clientHeight+'px';
		this.content_roll();
	}
	Scroll.prototype.scrollMove=function(){
		this.scroll.addEventListener('mousedown',(ev)=>{
			flag=0;
			ev=ev || window.event;
			var y=ev.pageY-this.scroll.offsetTop-this.content_big.offsetTop;
			document.onmousemove=(ev)=>{
				this.scroll.className='displayScroll';
				ev=ev || window.event;
				var scrollY=ev.pageY-y-this.content_big.offsetTop;
				scrollY=scrollY<0?0 : scrollY;
				scrollY=scrollY>this.bar.clientHeight-this.scroll.clientHeight?this.bar.clientHeight-this.scroll.clientHeight : scrollY;
				this.scroll.style.top=scrollY+'px';
				this.content_roll();
				ev.preventDefault();
			}
			document.onmouseup=()=>{
				document.onmousemove=null;
				if(flag){
					this.scroll.className='disappearScroll';
				}
				
			}
		})	
	}
	Scroll.prototype.content_roll=function(){
		var contentRoll=this.scroll.offsetTop/(this.bar.clientHeight-this.scroll.clientHeight)*(this.content.scrollHeight-this.content_big.clientHeight);
		this.content.style.top=-contentRoll+'px';
	}
	Scroll.prototype.displayScroll=function(){
		this.bigDiv.addEventListener('mouseover',()=>{
			this.scroll.className='displayScroll';
			flag=0;
			document.onmousewheel=(ev)=>{
				this.scroll.style.top=this.scroll.offsetTop-ev.wheelDelta/20+'px';
				if(this.scroll.offsetTop<=0){
					this.scroll.style.top=0 + 'px';
				}
				else if(this.scroll.offsetTop>=this.bar.clientHeight-this.scroll.clientHeight){
					this.scroll.style.top=this.bar.clientHeight-this.scroll.clientHeight+'px';
				}
				this.content_roll();
			}
		});
		this.bigDiv.addEventListener('mouseout',()=>{
			document.onmousewheel=null;
			this.scroll.className='disappearScroll';
			flag=1;
		})
	}
window.Scroll=Scroll;
})(window)
